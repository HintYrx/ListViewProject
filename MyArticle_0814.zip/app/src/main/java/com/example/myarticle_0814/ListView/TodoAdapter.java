package com.example.myarticle_0814.ListView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myarticle_0814.R;
import com.example.myarticle_0814.Todo;

import java.util.List;

/**
 * 数据要借助适配器传递给 ListView
 * 故适配器内须完成：确定子项布局、把适配器接收的数据传给子项的控件 这两个最重要的操作
 */
public class TodoAdapter extends ArrayAdapter<Todo> {

    /**
     * 对控件的实例进行缓存
     */
    static class ViewHolder {
        View itemView;
        Button button;
        TextView textView;

        public ViewHolder(View itemView) {
            this.itemView = itemView;
            button = itemView.findViewById(R.id.todo_item_button);
            textView = itemView.findViewById(R.id.todo_item_text_view);
        }
    }

    private final int RESOURCE_ID;

    /**
     * 构造方法
     *
     * @param context  上下文环境
     * @param resource 布局 id
     * @param objects  数据 list
     */
    public TodoAdapter(@NonNull Context context, int resource, @NonNull List<Todo> objects) {
        super(context, resource, objects);
        RESOURCE_ID = resource;
    }

    /**
     * 当滑动到子项时调用，功能：确定子项布局、把适配器接收的数据传给子项的控件
     *
     * @param position    当前子项的序号
     * @param convertView 缓存已经加载过的子项布局
     * @param parent      父布局
     * @return 当前子项的布局
     */
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View itemView;
        ViewHolder holder;

        if (convertView == null) {
            itemView = LayoutInflater.from(parent.getContext()).inflate(RESOURCE_ID, parent, false);
            holder = new ViewHolder(itemView);
            itemView.setTag(holder);
        } else {
            itemView = convertView;
            holder = (ViewHolder) itemView.getTag();
        }

        Todo data = getItem(position);
        holder.textView.setText(data.getTitle());
        holder.button.setOnClickListener(button -> ((Button) button).setText("√"));
        //  holder.itemView.setOnClickListener(view -> Toast.makeText(view.getContext(), "(comment) You clicked item" + position, Toast.LENGTH_SHORT).show());

        return itemView;
    }
}
