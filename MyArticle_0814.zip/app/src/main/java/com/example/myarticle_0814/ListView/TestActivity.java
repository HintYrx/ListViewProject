package com.example.myarticle_0814.ListView;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myarticle_0814.R;
import com.example.myarticle_0814.Todo;

import java.util.ArrayList;
import java.util.List;

public class TestActivity extends AppCompatActivity {

    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_test);

        lv = findViewById(R.id.lvt_list_view);
        TodoAdapter adapter = new TodoAdapter(this, R.layout.todo_item, getTodoList());
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View listView, int position, long id) {
                Toast.makeText(TestActivity.this, "You clicked item" + position, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * ListView 数据来源
     *
     * @return List<Ｔｏｄｏ> 类型的对象
     */
    private List<Todo> getTodoList() {
        List<Todo> todoList = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            Todo todo = new Todo("事件" + i);
            todoList.add(todo);
        }

        return todoList;
    }
}